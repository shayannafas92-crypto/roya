# Emberfall — ساخت APK بدون PC

این پروژه برای ساخت APK با GitHub Actions آماده شده است.

## ساخت APK فقط با گوشی

1. در GitHub یک Repository جدید بساز.
2. تمام محتویات این پروژه را داخل Repository آپلود کن.
3. وارد تب **Actions** شو.
4. Workflow با نام **Build Emberfall Android APK** را انتخاب کن.
5. روی **Run workflow** بزن.
6. چند دقیقه صبر کن تا Build تمام شود.
7. وارد اجرای موفق Workflow شو.
8. در بخش **Artifacts** فایل `emberfall-app-debug` را دانلود کن.
9. فایل ZIP دانلودشده را باز کن؛ داخل آن `app-debug.apk` قرار دارد.
10. APK را روی گوشی نصب کن.

## نکته

برای نصب APK ممکن است Android از شما اجازه نصب برنامه از منبع ناشناس را بخواهد. اگر نمایش داده شد، اجازه نصب برای مرورگر/فایل‌منیجر مورد استفاده را فعال کنید.

## ساخت خودکار

Workflow علاوه بر اجرای دستی، روی push به شاخه `main` یا `master` نیز اجرا می‌شود.

## خروجی

`android/app/build/outputs/apk/debug/app-debug.apk`
