# Emberfall Android — one-click debug APK build

## Fastest build

### Windows
Double-click `build-debug-apk.bat`.

### macOS / Linux
Run `./build-debug-apk.sh` from this `android/` directory.

The APK is produced at:

`app/build/outputs/apk/debug/app-debug.apk`

## Requirements

- JDK 17 or newer (JDK 21 is supported)
- Android SDK with **Android 35 / API 35** installed
- Android SDK Build-Tools installed
- Internet access the first time the Gradle bootstrap launcher runs, so Gradle 8.9 and Maven/Google dependencies can be downloaded

Android Studio can install/configure the SDK components for you. Open the `android/` directory as a project, then run the build script or use **Build > Make Project**.

## Gradle wrapper

This project includes:

- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.properties`

The launcher bootstraps the pinned Gradle 8.9 distribution into the user's Gradle cache if it is missing, then runs Gradle with `--no-daemon`. This keeps the project reproducible without requiring a system-wide Gradle installation.

## Android SDK location

If the SDK is not detected automatically, set one of:

- `ANDROID_HOME`
- `ANDROID_SDK_ROOT`

or create `local.properties` in this directory:

`local.properties`

with:

`sdk.dir=/absolute/path/to/Android/sdk`

Do not commit `local.properties`.

## Install directly to a connected phone

After enabling USB debugging and accepting the computer on the phone:

```bash
./gradlew :app:installDebug
```

Then launch **Emberfall** from the phone's app drawer.

## Verify the APK

```bash
./gradlew :app:assembleDebug
```

Expected output:

`app/build/outputs/apk/debug/app-debug.apk`

## Troubleshooting

### `SDK location not found`
Install Android SDK Platform 35 and Build-Tools from Android Studio's SDK Manager, then set `ANDROID_HOME`/`ANDROID_SDK_ROOT` or create `local.properties`.

### `JAVA_HOME is not set`
Install a JDK and set `JAVA_HOME` to its installation directory.

### Gradle cannot download
Check that the machine has internet access. The first build downloads Gradle 8.9 plus Android Gradle Plugin/Maven dependencies. Later builds use the local Gradle cache.

### APK installs but game does not start
The game assets are packaged under `app/src/main/assets/www`, so the Android app does not require a remote web server. Rebuild with:

```bash
./gradlew clean :app:assembleDebug
```

