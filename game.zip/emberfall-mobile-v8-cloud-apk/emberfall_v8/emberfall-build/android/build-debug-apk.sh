#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
./gradlew clean :app:assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then echo "ERROR: APK was not produced at $APK" >&2; exit 2; fi
echo "BUILD SUCCESS"
echo "APK: $(pwd)/$APK"
