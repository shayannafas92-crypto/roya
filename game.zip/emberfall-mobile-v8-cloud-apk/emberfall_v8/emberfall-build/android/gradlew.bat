@echo off
setlocal
set APP_HOME=%~dp0
set GRADLE_VERSION=8.9
set CACHE_DIR=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin
set DIST_ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set DIST_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
set DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%
if not exist "%DIST_DIR%\bin\gradle.bat" (
  echo Emberfall: downloading Gradle %GRADLE_VERSION%...
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing '%DIST_URL%' -OutFile '%DIST_ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%DIST_ZIP%' '%CACHE_DIR%'"
)
call "%DIST_DIR%\bin\gradle.bat" --no-daemon %*
