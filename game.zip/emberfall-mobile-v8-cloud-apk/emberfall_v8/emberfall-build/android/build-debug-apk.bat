@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat clean :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%
if not exist "app\build\outputs\apk\debug\app-debug.apk" (
  echo ERROR: APK was not produced.
  exit /b 2
)
echo BUILD SUCCESS
echo APK: %CD%\app\build\outputs\apk\debug\app-debug.apk
