# Emberfall Android Build Guide

The Android target is a self-contained landscape application. Game content is bundled into the APK under `app/src/main/assets/www`.

## One-click APK

**Windows:** double-click `build-debug-apk.bat`.

**macOS/Linux:** run `./build-debug-apk.sh`.

Both commands run a clean debug build and fail if `app-debug.apk` is not created.

Output:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Toolchain

- Android Gradle Plugin: 8.5.2
- Gradle: 8.9
- Compile/Target SDK: 35
- Minimum SDK: 23
- Java: 17+ recommended

## Android Studio

1. Install Android Studio.
2. Install Android SDK Platform 35 and Build-Tools.
3. Open the `android/` directory.
4. Wait for Gradle sync.
5. Run `Build > Build APK(s)` or use the included one-click script.

## Phone testing

Enable Developer Options and USB debugging on the Android phone, connect it, then run:

```bash
./gradlew :app:installDebug
```

The app is forced to landscape and uses touch controls.

## Reproducibility

The project pins the Gradle version in `gradle/wrapper/gradle-wrapper.properties`. The included `gradlew`/`gradlew.bat` bootstrap launcher downloads that exact Gradle distribution when necessary, so a system Gradle installation is not required.

The build still requires the Android SDK and access to Google's/Maven's artifact repositories for the first dependency resolution.
