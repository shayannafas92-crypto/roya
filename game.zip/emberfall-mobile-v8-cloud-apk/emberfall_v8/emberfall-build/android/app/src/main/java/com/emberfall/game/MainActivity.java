package com.emberfall.game;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  requestWindowFeature(Window.FEATURE_NO_TITLE);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
  web=new WebView(this);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setMediaPlaybackRequiresUserGesture(false);
  web.setOverScrollMode(View.OVER_SCROLL_NEVER); web.setWebViewClient(new WebViewClient());
  web.setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
  setContentView(web); web.loadUrl("file:///android_asset/www/index.html");
 }
 @Override public void onPause(){super.onPause(); if(web!=null) web.onPause();}
 @Override public void onResume(){super.onResume(); if(web!=null) web.onResume();}
 @Override public void onBackPressed(){ if(web!=null) web.evaluateJavascript("document.getElementById('menu').style.display='grid';",null); else super.onBackPressed(); }
}