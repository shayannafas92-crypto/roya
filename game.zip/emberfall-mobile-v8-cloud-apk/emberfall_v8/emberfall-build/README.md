# Emberfall: Twin Rivers — Mobile Playable Build
Self-contained mobile revision. Open index.html in a modern browser or build the Android project in `android/`.
Controls: tap a card, then tap your blue half of the arena. Energy regenerates. Units fight and towers can be destroyed. Training bot responds.
