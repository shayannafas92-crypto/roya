# Emberfall Android
This revision is a self-contained touch-first HTML5 game packaged for Android WebView. It has no CDN/gameplay dependency, so the game assets load from the APK itself. Build with Android Studio/Gradle using SDK 35. Landscape is enforced.
